<footer>
    <div class="footer-content">
        <h3>24/7 DeliMed</h3>
        <p>Address: 123 Main Street, Dhaka Bangladesh</p>
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">About Us</a></li>
            <li><a href="#">Contact Us</a></li>
        </ul>
    </div>

    <div class="footer-bottom">
        <p>Copyright &copy; 2024 24/7 DeliMed
        <a href="admin_login.html">Admin</a></p>
    </div>

</footer>
</body>
